package com.mygdx.game;

public interface Button {
    public void buttons();

}
